
<?php $__env->startSection('contenid-principal'); ?>

<div class="row">
    <div class="col">
        <table class="table">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">First</th>
                <th scope="col">Last</th>
                <th scope="col">Handle</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $profesor_propuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor_propuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <th scope="row"><?php echo e($profesor_propuesta->propuesta_id); ?></th>
                <td><?php echo e($profesor_propuesta->profesor_rut); ?></td>
                <td><?php echo e($profesor_propuesta->fecha); ?></td>
                <td><?php echo e($profesor_propuesta->hora); ?></td>
                <td><?php echo e($profesor_propuesta->comentario); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/profesor/cometarios.blade.php ENDPATH**/ ?>