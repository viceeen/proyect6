
<?php $__env->startSection('contenido-principal'); ?>
<br>
<table class="table table-secondary table-striped">
  <thead>
    <tr>
      <th scope="col">Rut</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th colspan="2"></th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $profesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th><?php echo e($profesor->rut); ?></th>
      <td><?php echo e($profesor->nombre); ?></td>
      <td><?php echo e($profesor->apellido); ?></td>
      <td>
        <a href="<?php echo e(route('profesor.edit',$profesor->rut)); ?>" class="btn btn-primary">a</a>
      </td>
      <td>
        <form method="POST" action="<?php echo e(route('profesor.destroy',$profesor->rut)); ?>">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-secondary">delete</button>
        
        </form>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vicen\OneDrive\Escritorio\proyecto\proyecto\resources\views/administrador/profesores.blade.php ENDPATH**/ ?>