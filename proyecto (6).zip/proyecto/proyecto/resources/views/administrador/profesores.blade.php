@extends('template.master')
@section('contenido-principal')
<br>
<table class="table table-secondary table-striped">
  <thead>
    <tr>
      <th scope="col">Rut</th>
      <th scope="col">Nombre</th>
      <th scope="col">Apellido</th>
      <th colspan="2"></th>
    </tr>
  </thead>
  <tbody>
    @foreach($profesores as $profesor)
    <tr>
      <th>{{$profesor->rut}}</th>
      <td>{{$profesor->nombre}}</td>
      <td>{{$profesor->apellido}}</td>
      <td>
        <a href="{{route('profesor.edit',$profesor->rut)}}" class="btn btn-primary">a</a>
      </td>
      <td>
        <form method="POST" action="{{route('profesor.destroy',$profesor->rut)}}">
        @method('DELETE')
        @csrf
        <button type="submit" class="btn btn-secondary">delete</button>
        
        </form>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>


@endsection