@extends('template.master')
@section('contenido-principal')

<div class="row">
    <div class="col">
        <div class="card">
            <div class="card-header">
                Editar Estado
            </div>
            <div class="card-body">
                <form method="POST"action="{{route('propuestas.update',$propuesta->id)}}">
                    @method('PUT')
                    @csrf
                    <label for="estado">Cambiar Estado</label>
                    <input name="estado" id="estado" type="integer">
                    <button type="submit" class="btn btn-outline-secondary">Editar</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection