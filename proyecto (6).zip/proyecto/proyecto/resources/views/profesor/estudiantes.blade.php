@extends('template.master')
@section('contenido-principal')

<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Rut</th>
      <th scope="col">Fecha</th>
      <th scope="col">Documento</th>
      <th scope="col">Estado</th>
      <th scope="col">Comentario</th>
    </tr>
  </thead>
  <tbody>
    @foreach($estudiante->propuesta as $index=>$propuesta)
    <tr>
      <td>{{$propuesta->id}}</td>
      <td>{{$propuesta->estudiante_rut}}</td>
      <td>{{$propuesta->fecha}}</td>
      <td>{{$propuesta->documento}}</td>
      <td>
        <select class="form-select" aria-label="Default select example" disabled>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='0') selected @endif>Esperado Revision</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='1') selected @endif>Aprobado</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='2') selected @endif>Rechazado</option>
          <option value="{{$propuesta->estado}}"@if($propuesta->estado=='3') selected @endif>Modificar Propuesta</option>
        </select>
      </td>
      <td>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
          Revisar
        </button>
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Agregar Comentario</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form method="POST"action="{{route('comentario.store')}}">
                  @csrf
                  <div class="mb-3">
                    <label class="form-label"for="profesor_rut">Ingrese su rut</label>
                    <input class="form-control"type="text" name="profesor_rut" id="profesor_rut">
                  </div><div class="mb-3">
                    <label class="form-label"for="propuesta_id">Ingrese ID de propuesta</label>
                    <input class="form-control"type="text" name="propuesta_id" id="propuesta_id">
                  </div>
                  <div class="mb-3">
                    <label class="form-label"for="comentario">Comentario</label>
                    <input class="form-control"type="text" name="comentario" id="comentario">
                  </div>
                  
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
                </form>
              </div>
  
            </div>
          </div>
        </div>
      </td>
      <td>
        <a href="{{route('comentario.index',$propuesta->id )}}" class="btn btn-secondary">Ver comentarios</a>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>




@endsection